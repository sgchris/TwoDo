db_host = "<host>"
db_username = "<user>"
db_password = "<pass>"
db_name = "<dbname>" 