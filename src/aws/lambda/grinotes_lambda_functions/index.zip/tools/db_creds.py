db_host = "grinotes.cemssk6v1d31.eu-central-1.rds.amazonaws.com"
db_username = "grinotes"
db_password = "WmuPLVGj3jG6fTKL"
db_name = "grinotes" 
